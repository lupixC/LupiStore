#puro bloatware pero funciona
import os 
import tkinter as tk
from PIL import Image, ImageTk
import minecraft_launcher_lib
import subprocess
import uuid
import threading
from tkinter import ttk
import time
from tkinter import filedialog as fd

window = tk.Tk() # tikii tikii tikiii tu tiki ti takaaaa (tkinter)
BASE_W, BASE_H = 905, 680 #resolucion base y alto de la ventana, aun asi se puede escalar 


window.title("Lupi Launcher") #le pongo un nombre al launcher para que no se vea untitled we
window.configure(bg="#b3c0a2") # el fondo de pantalla
window.geometry(f"{BASE_W}x{BASE_H}") #aca uso las varibles (PAPEADO CON AURA)

canvas = tk.Canvas(
    window, bg="#b3c0a2", bd=0, highlightthickness=0, relief="ridge") # hace un canvas
canvas.place(x=0, y=0, relwidth=1, relheight=1) #supongo que es para centrar


dirname = os.path.dirname #es una funcion que se usa en el codigo de aqui  |
separator = os.path.sep # esto se usa porque en linuxito y mac el slash    |    esta asi '/' pero en windows asi '\'
dir_ = dirname(__file__) #<------------------------------------------------|
minecraft_dir = dir_ + separator +'Minecraft' # deberia salir asi depende-de-tu-compu/LupiLauncher/Minecraft
JAVA_PATH = subprocess.run(["where.exe", "java"], capture_output=True, text=True).stdout.splitlines()[0].strip()
current_max = 0 # 0%
label_playing = tk.Label(window, bg="#b3c0a2", fg="#1d1b20", font=("Roboto", 10))# crea un texto que se va a usar en el futuro
mod = 0
def forge(): # cambia un parametro que hace que instale forge en vez de vanilla o forge
    global mod
    mod = 1
def fabric():
    global mod 
    mod = 2 # cambia un parametro que hace que instale fabric en vez de vanilla o fabric

def modpack_chooser():
    file = fd.askopenfilename()

    if file:
        modpack_installed.pack_forget()
        modpack_installing.pack(side=tk.BOTTOM, pady=2)

        def install():
            minecraft_launcher_lib.mrpack.install_mrpack(file, minecraft_dir)

            window.after(0, modpack_installing.pack_forget)
            window.after(
                0,
                lambda: modpack_installed.pack(side=tk.BOTTOM, pady=2)
            )
            window.after(2000, modpack_installed.pack_forget)

        threading.Thread(target=install, daemon=True).start()





def LupiLaunch(): # aca es donde el juego se ejecuta la cebollaaaa
    progress_bar = ttk.Progressbar(window, orient=tk.HORIZONTAL, length=200, mode='determinate') #crea una barra de carga
    def version(): 
        return textbox_1.get().strip() # agarra de la cajita de texto super UwU el version
    def fullversion(): 
        if mod == 2:
         content = os.listdir(f'{minecraft_dir}{separator}versions{separator}') #la carpeta de las versiones
         filtered = list(filter(lambda folder: folder.startswith('fabric') and version() in folder, content)) # busca el nombre de la version de fabric
         if filtered:
            return filtered[0] # lo muestra
         else:
            return None
        elif mod == 1:
             content = os.listdir(f'{minecraft_dir}{separator}versions{separator}') #la carpeta de las versiones
             filtered = list(filter(lambda folder: folder.startswith(f'{version()}-forge'), content)) # busca el nombre de la version de forge
             if filtered:
              return filtered[0] # lo muestra
             else:
              return None
        else:
         return version() # Vanilla
    def forgeInstallversion(): # hay un bug en 26.2 con forge 65, hay que cambiar la version de forge con una que tenga la misma aura que 26.2
        if version() == '26.2':
            return '26.2-65.1.2'
        else:
            return minecraft_launcher_lib.forge.find_forge_version(version())


    label_status = tk.Label(window, text=(f"Downloading packages for Minecraft {version()}"), bg="#b3c0a2", fg="#1d1b20", font=("Roboto", 10)) #crea un texto para marcar que minecraft se esta descargando


    def minprocess(): #usando subprocess, este comando abre el minecraft, tambien pone el texto de que estas jugando (papeado)
        label_playing.pack(side=tk.BOTTOM, pady=2),subprocess.Popen(minecraft_launcher_lib.command.get_minecraft_command(fullversion(), minecraft_dir, options)),window.after(6000, label_playing.pack_forget) #configura el texto, tambien ejecuta minecraft
    def mininstall(): # este comando instala minecraft y ejecuta minecraft. Tambien pone los textos de descargando minecraft y jugando minecraft, y elimina el progress bar y los textos no necesarios, tambien si quieres fabric, forge o vanilla, elije el comando correcto (mucho texto) 
         if mod == 2:
           label_playing.pack_forget(),progress_bar.pack(),minecraft_launcher_lib.fabric.install_fabric(version(), minecraft_dir, callback=callback,java=JAVA_PATH),progress_bar.pack_forget(),label_status.pack_forget(),minprocess()  # instala fabric y lo ejecuta
         elif mod == 1:
            label_playing.pack_forget(),progress_bar.pack(),minecraft_launcher_lib.forge.install_forge_version(forgeInstallversion(),minecraft_dir,callback = callback,java=JAVA_PATH),progress_bar.pack_forget(),label_status.pack_forget(),minprocess()  # instala forge y lo ejecuta *COMO MACHINE LEARNING FUNCIONABA ANTES REFERENCIA* (elif)
         else:
           label_playing.pack_forget(),progress_bar.pack(),minecraft_launcher_lib.install.install_minecraft_version(version(), minecraft_dir, callback=callback),progress_bar.pack_forget(),label_status.pack_forget(),minprocess() #instala vanilla y lo ejecuta


    def username():
         return textbox_2.get().strip() # agarra de la cajita de texto super UwU el username
    def mininstallThread(): #esta version es un hilo, yiaa me pase, esto hace que se convierta en un proceso en segundo plano para que la interfaz no se congele
        threading.Thread(target=mininstall, daemon=True).start()
    #proceso de descarga 

    def set_status(status: str): #define un status para imprimir la variable status que se obtiene en el futuro
        print(status)
    def set_progress(progress: int): 
        if current_max != 0: #si no es 0 entonces imprimir porcentaje
         percent_task = (progress / current_max) * 100 # digamos que minecraft tiene 250 paquetes y se instalaron 100, entonces usamos esta formula para convertirlo a porcentaje 100 dividido 250 por 100
         progress_bar['value'] = percent_task #el valor que la barra obtiene
         window.update_idletasks() #actualizar la ventana


    def set_max(new_max: int): # hacer nuevo tope
        global current_max, current_package
        current_max = new_max

    callback = { #informacion completa de la descarga
        "setStatus": set_status,
        "setProgress": set_progress,
        "setMax": set_max
}
    options = {
    "username": username(), # mi nombre es alejandro y soy esquizofrenico
    "uuid": str(uuid.uuid3(uuid.NAMESPACE_DNS, username())), # UUID y token son generados por la cuenta de microsoft, como no tengo una, hay que ponerse creativos heh
    "token": "token", # token.
    "executablePath": JAVA_PATH
}
    # en resumen si la version esta instalada, no se intala (ENSERIO?) y se juega, si no esta instalada se instala y se juega 
    if os.path.isdir(f'{minecraft_dir}{separator}versions{separator}{fullversion()}'): #comprueba si la version esta instalada buscando si la carpeta existe
          label_playing.config(text=f"Playing Minecraft {version()}"),
          minprocess()

    else: 
          label_playing.config(text=f"Loading Minecraft {version()}"),
          label_status.pack(side=tk.BOTTOM, pady=2)# muestra el texto para marcar que minecraft se esta descargando
          progress_bar.pack(side=tk.BOTTOM,pady=15)#muestra la barra de carga
          mininstallThread()  #llama a la funcion para instalar minecraft en segundo plano (Aura)

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets") #usa el parametro ya antes mencionado para buscar archivos

pil_images = {
    "1": Image.open(os.path.join(ASSETS, "1.png")), #los nombres de las imagenes estan asi porque sigo a mike y porque recuerda que lo importe de figma
    "2": Image.open(os.path.join(ASSETS, "2.png")), #los nombres de las imagenes estan asi porque sigo a mike y porque recuerda que lo importe de figma
    "3": Image.open(os.path.join(ASSETS, "3.png")), #los nombres de las imagenes estan asi porque sigo a mike y porque recuerda que lo importe de figma
    "4": Image.open(os.path.join(ASSETS, "4.png")), #los nombres de las imagenes estan asi porque sigo a mike y porque recuerda que lo importe de figma
}
photo_refs = {} #si tu crees que no hacen nada es skill issue
widgets = [] #si tu crees que no hacen nada es skill issue

def rebuild(scale): # en resumen es un sistema para rescalar la ventana, imagenes y botones al mismo tiempo 
    canvas.delete("all")
    for key, img in pil_images.items():
        if key == "4":
            continue
        w, h = img.size
        nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
        resized = img.resize((nw, nh), Image.LANCZOS)
        photo_refs[key] = ImageTk.PhotoImage(resized)

    positions = { 
        "1": (141, 168),#posiciones de imagenes como diccionario
        "2": (160, 45), #posiciones de imagenes como diccionario
        "3": (694, 436), #posiciones de imagenes como diccionario
    } 

    for key, (x, y) in positions.items(): #en resumen se usa para rescalar limpiamente
        canvas.create_image(int(x * scale), int(y * scale), image=photo_refs[key])

    canvas.create_text(
        int(12 * scale), int(313 * scale), anchor="nw", #tamano (no tengo ñ )= )
        text="Insert the Minecraft version.", fill="#1d1b20", # texto
        font=("Roboto", max(1, int(24 * scale)) * -1) # font 
    )

    canvas.create_text(
        int(12 * scale), int(495 * scale), anchor="nw", #tamano (no tengo ñ )= )
        text="Insert your username.", fill="#1d1b20", # texto
        font=("Roboto", max(1, int(24 * scale)) * -1) # font
    )

    canvas.create_text(
        int(22 * scale), int(17 * scale), anchor="nw", #tamano (no tengo ñ )= )
        text="Lupi Launcher", fill="#1d1b20", # texto
        font=("Roboto", max(1, int(24 * scale)) * -1) # font
    )

    canvas.create_text(
        int(23 * scale), int(49 * scale), anchor="nw", #tamano (no tengo ñ )= )
        text="The best minecraft launcher in the world.", fill="#1d1b20", # texto
        font=("Roboto", max(1, int(14 * scale)) * -1) # font
    )

    if widgets: # se va de mis capaciades de programador de assembly (larp larp larp), leyendolo un poco es un sistema de escalamiento
        e1, e2, btn = widgets[0], widgets[1], widgets[2]
        fs = max(1, int(12 * scale))
        e1.configure(font=("Roboto", fs))
        e1.place_configure(
            x=int(4 * scale), y=int(358 * scale),
            width=int(392 * scale), height=int(56 * scale)
        )
        e2.configure(font=("Roboto", fs))
        e2.place_configure(
            x=int(3 * scale), y=int(546 * scale),
            width=int(392 * scale), height=int(56 * scale)
        )
        bw, bh = pil_images["4"].size
        nw, nh = max(1, int(bw * scale)), max(1, int(bh * scale))
        resized_btn = pil_images["4"].resize((nw, nh), Image.LANCZOS)
        photo_refs["4"] = ImageTk.PhotoImage(resized_btn)
        btn.configure(image=photo_refs["4"])
        btn.place_configure(
            x=int(709 * scale), y=int(9 * scale),
            width=nw, height=nh
        )

def rescale(event=None): #hacerlo mas responsive
    w = window.winfo_width() #hacerlo mas responsive
    h = window.winfo_height() #hacerlo mas responsive
    if w < 10 or h < 10: #hacerlo mas responsivef_butt
        return #hacerlo mas responsive
    scale = min(w / BASE_W, h / BASE_H) #hacerlo mas responsive
    rebuild(scale) #hacerlo mas responsive

textbox_1 = tk.Entry(
    bd=0, bg="#ece6f0", fg="#000000", #caja de texto blanca
    insertbackground="#000000", highlightthickness=0 #caja de texto blanca
)

textbox_2 = tk.Entry(
    bd=0, bg="#ece6f0", fg="#000000", #caja de texto blanca *la secuela*
    insertbackground="#000000", highlightthickness=0 #caja de texto blanca *la secuela*
)

button_1 = tk.Button( # si lo presiona instala y inicia minecraft
     borderwidth=0, highlightthickness=0,
    command=lambda: (
        LupiLaunch()
    )
)
buttons_frame = tk.Frame(window,bg="#b3c0a2")
buttons_frame.pack(side=tk.BOTTOM, pady=15)
add_modpack_button = tk.Button(buttons_frame,text="Add Modpack" ,command= modpack_chooser)
fabric_button = tk.Button( buttons_frame,text="Fabric" ,command= fabric) #llama la funcion fabric para elejir la version fabric
forge_button = tk.Button(buttons_frame,text="Forge" ,command= forge) #llama la funcion forge para elejir la version forge
modpack_installing = tk.Label(window, text=(f"Installing Modpack..."), bg="#b3c0a2", fg="#1d1b20", font=("Roboto", 10))
modpack_installed = tk.Label(window, text=(f"Modpack installed!"), bg="#b3c0a2", fg="#1d1b20", font=("Roboto", 10))
fabric_button.pack(side=tk.LEFT, padx=10)
forge_button.pack(side=tk.LEFT, padx=10)
add_modpack_button.pack(side=tk.LEFT, padx=10)



widgets = [textbox_1, textbox_2, button_1] #cosas interactivas
# cosas de tkinter
rebuild(1.0)

try:
    window.attributes('-type', 'normal')
except:
    pass

window.bind("<Configure>", rescale)
window.mainloop()
